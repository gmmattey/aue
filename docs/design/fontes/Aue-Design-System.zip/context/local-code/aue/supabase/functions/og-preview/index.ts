import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || '';
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY') || '';

serve(async (req) => {
  const url = new URL(req.url);
  const challengeId = url.searchParams.get('id');

  if (!challengeId) {
    return new Response('Challenge ID is required', { status: 400 });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

  const { data: challenge, error } = await supabase
    .from('desafios')
    .select('*, challenger_result:resultados!desafios_challenger_result_id_fkey(*)')
    .eq('id', challengeId)
    .single();

  let title = 'Desafio Auê!';
  let description = 'Alguém te desafiou para um duelo de arrotos no Auê!';

  const escapeHtml = (unsafe: string) => {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
  };

  if (!error && challenge && challenge.challenger_result) {
    const score = Number(challenge.challenger_result.score).toFixed(1);
    const playerName = escapeHtml(challenge.challenger_result.player_name || 'Alguém');
    const classification = escapeHtml(challenge.challenger_result.classification || '');
    title = `${playerName} fez ${score} no Auê!`;
    description = `Classificação: ${classification}. Você consegue bater esse recorde?`;
  }

  const html = `
    <!DOCTYPE html>
    <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${title}</title>
        
        <!-- Open Graph Meta Tags -->
        <meta property="og:title" content="${title}" />
        <meta property="og:description" content="${description}" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://aue.app/d/${challengeId}" />
        <!-- For future implementation: <meta property="og:image" content="url_to_dynamic_image" /> -->

        <!-- Twitter Card Meta Tags -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="${title}">
        <meta name="twitter:description" content="${description}">
      </head>
      <body>
        <h1>${title}</h1>
        <p>${description}</p>
        <script>
          // Redirect the user to the actual app URL
          window.location.replace('/d/${challengeId}');
        </script>
      </body>
    </html>
  `;

  return new Response(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8' },
  });
});
