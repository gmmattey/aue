import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getChallenge, completeChallenge, createResult } from '../../db/supabase';
import { AudioRecorder } from './AudioRecorder';
import { compareResults, type ScoreResult } from './rules';

export const ChallengeView: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [challengeData, setChallengeData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      getChallenge(id)
        .then(data => {
          setChallengeData(data);
          if (data.challenged_result) {
            determineWinner(data.challenger_result, data.challenged_result);
          }
        })
        .catch(err => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [id]);

  const determineWinner = (resA: any, resB: any) => {
    const formattedA: ScoreResult = {
      score: resA.score,
      classification: resA.classification,
      isArtificial: resA.is_artificial,
      partialScores: {
        duration: resA.duration,
        power: resA.power,
        depth: resA.depth,
        texture: resA.texture,
        origin: resA.origin_score
      }
    };
    const formattedB: ScoreResult = {
      score: resB.score,
      classification: resB.classification,
      isArtificial: resB.is_artificial,
      partialScores: {
        duration: resB.duration,
        power: resB.power,
        depth: resB.depth,
        texture: resB.texture,
        origin: resB.origin_score
      }
    };

    const result = compareResults(formattedA, formattedB);
    if (result === 'A') setWinner('Desafiante venceu!');
    else if (result === 'B') setWinner('Você venceu!');
    else setWinner('Empate Técnico do Gás!');
  };

  const handleRecordingComplete = async (scoreResult: ScoreResult) => {
    try {
      const dbResult = await createResult({
        score: scoreResult.score,
        classification: scoreResult.classification,
        is_artificial: scoreResult.isArtificial,
        duration: scoreResult.partialScores.duration,
        power: scoreResult.partialScores.power,
        depth: scoreResult.partialScores.depth,
        texture: scoreResult.partialScores.texture,
        origin_score: scoreResult.partialScores.origin,
        origin_type: 'Unknown',
        player_name: 'Desafiado'
      });

      await completeChallenge(id!, dbResult.id);
      setChallengeData({
        ...challengeData,
        challenged_result: dbResult
      });
      determineWinner(challengeData.challenger_result, dbResult);
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div>Carregando desafio...</div>;
  if (!challengeData) return <div>Desafio não encontrado.</div>;

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Desafio {id}</h2>
      
      <div style={{ padding: '15px', background: '#ffebee', borderRadius: '8px', marginBottom: '20px' }}>
        <h3>Desafiante</h3>
        <p>Score: <strong>{Number(challengeData.challenger_result.score).toFixed(1)}</strong></p>
        <p>Classificação: {challengeData.challenger_result.classification}</p>
      </div>

      {!challengeData.challenged_result ? (
        <div>
          <h3>Sua vez de responder:</h3>
          <AudioRecorder onRecordingComplete={handleRecordingComplete} hideChallengeButton />
        </div>
      ) : (
        <div style={{ padding: '15px', background: '#e8f5e9', borderRadius: '8px', marginBottom: '20px' }}>
          <h3>Você</h3>
          <p>Score: <strong>{Number(challengeData.challenged_result.score).toFixed(1)}</strong></p>
          <p>Classificação: {challengeData.challenged_result.classification}</p>
        </div>
      )}

      {winner && (
        <div style={{ padding: '20px', background: '#fff3e0', borderRadius: '8px', textAlign: 'center', marginTop: '20px' }}>
          <h2>Resultado Final</h2>
          <h3>{winner}</h3>
          <Link to="/" style={{ display: 'inline-block', marginTop: '10px', padding: '10px', background: '#ccc', textDecoration: 'none', color: '#000', borderRadius: '4px' }}>
            Voltar ao Início
          </Link>
        </div>
      )}
    </div>
  );
};
