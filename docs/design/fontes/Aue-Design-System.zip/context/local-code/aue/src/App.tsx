import { useEffect, useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import './App.css'
import { AudioRecorder } from './features/audio/AudioRecorder'
import { ChallengeView } from './features/audio/ChallengeView'
import { supabase, signInWithGoogle, signInWithTikTok, signInWithTwitter, signOut } from './db/supabase'

function ProfileView({ session }: { session: any }) {
  const [profile, setProfile] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [apelido, setApelido] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (session?.user?.id) {
      fetchProfile();
    }
  }, [session]);

  const fetchProfile = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();
    if (data) {
      setProfile(data);
      setApelido(data.apelido || '');
    }
  };

  const getTitle = (nivel: number) => {
    if (nivel >= 10) return "Deus do Auê";
    if (nivel >= 5) return "Mestre Arrotador";
    if (nivel >= 3) return "Trovão Humano";
    return "Iniciante do Gás";
  };

  const updateProfile = async (avatarUrl?: string) => {
    try {
      const updates = {
        apelido,
        ...(avatarUrl && { avatar_url: avatarUrl })
      };

      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', session.user.id);

      if (error) throw error;
      
      setIsEditing(false);
      fetchProfile();
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Erro ao atualizar o perfil.');
    }
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setUploading(true);

      if (!event.target.files || event.target.files.length === 0) {
        throw new Error('You must select an image to upload.');
      }

      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `avatar_${Math.random()}.${fileExt}`;
      const filePath = `${session.user.id}/${fileName}`;

      // Check size client-side as well
      if (file.size > 2 * 1024 * 1024) {
        throw new Error('File size exceeds 2MB limit.');
      }

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data } = supabase.storage.from('avatars').getPublicUrl(filePath);
      
      if (data.publicUrl) {
        await updateProfile(data.publicUrl);
      }
    } catch (error: any) {
      alert(error.message);
    } finally {
      setUploading(false);
    }
  };

  if (!session) return <p style={{ padding: '20px' }}>Faça login para ver seu perfil.</p>;
  if (!profile) return <p style={{ padding: '20px' }}>Carregando perfil...</p>;

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: '0 auto', textAlign: 'center' }}>
      <h2>Seu Perfil</h2>
      <div style={{ background: '#f5f5f5', padding: '20px', borderRadius: '8px' }}>
        {profile.avatar_url && (
          <img 
            src={profile.avatar_url} 
            alt="Avatar" 
            style={{ width: '100px', height: '100px', borderRadius: '50%', objectFit: 'cover', marginBottom: '15px' }} 
          />
        )}
        
        {isEditing ? (
          <div>
            <div style={{ marginBottom: '10px' }}>
              <label style={{ display: 'block', fontSize: '0.9em', marginBottom: '5px' }}>Alterar Foto:</label>
              <input 
                type="file" 
                accept="image/png, image/jpeg, image/webp" 
                onChange={handleAvatarUpload}
                disabled={uploading}
                style={{ width: '100%' }}
              />
              {uploading && <p style={{ fontSize: '0.8em', color: 'blue' }}>Enviando imagem...</p>}
            </div>
            <div style={{ marginBottom: '10px' }}>
              <label style={{ display: 'block', fontSize: '0.9em', marginBottom: '5px' }}>Apelido:</label>
              <input 
                type="text" 
                value={apelido} 
                onChange={(e) => setApelido(e.target.value)}
                style={{ padding: '8px', width: '90%' }}
              />
            </div>
            <button onClick={() => updateProfile()} style={{ padding: '8px 15px', background: '#4caf50', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', marginRight: '10px' }}>Salvar</button>
            <button onClick={() => setIsEditing(false)} style={{ padding: '8px 15px', background: '#ccc', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancelar</button>
          </div>
        ) : (
          <div>
            <h3>Nível {profile.nivel}</h3>
            <p style={{ fontSize: '1.2em', fontWeight: 'bold', color: '#1976d2' }}>{getTitle(profile.nivel)}</p>
            <p>XP Total: {profile.xp_total}</p>
            <p>Apelido: {profile.apelido}</p>
            <button onClick={() => setIsEditing(true)} style={{ padding: '8px 15px', background: '#1976d2', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', marginTop: '10px' }}>Editar Perfil</button>
          </div>
        )}
      </div>
    </div>
  );
}

function App() {
  const [session, setSession] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogin = async (provider: 'google' | 'tiktok' | 'twitter') => {
    try {
      let res;
      if (provider === 'google') res = await signInWithGoogle();
      else if (provider === 'tiktok') res = await signInWithTikTok();
      else if (provider === 'twitter') res = await signInWithTwitter();
      
      if (res?.error) {
        throw res.error;
      }
    } catch (err: any) {
      console.error('Login error:', err);
      alert(`Erro no login: ${err.message || 'Usuário cancelou ou falha de rede.'}`);
    }
  };

  return (
    <Router>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 20px', borderBottom: '1px solid #ccc' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <h1 style={{ margin: 0 }}>
            <Link to="/" style={{ textDecoration: 'none', color: 'inherit' }}>Auê MVP</Link>
          </h1>
          <nav>
            <Link to="/" style={{ marginRight: '10px' }}>Gravar</Link>
            <Link to="/perfil">Perfil</Link>
          </nav>
        </div>
        <div>
          {session ? (
            <div>
              <span style={{ marginRight: '10px', fontSize: '0.9em' }}>
                {session.user.email || session.user.user_metadata?.full_name || 'Autenticado'}
              </span>
              <button onClick={signOut} style={{ padding: '5px 10px', cursor: 'pointer' }}>Sair</button>
            </div>
          ) : (
            <div style={{ display: 'flex', gap: '5px' }}>
              <button onClick={() => handleLogin('google')} style={{ padding: '5px 10px', cursor: 'pointer' }}>Google</button>
              <button onClick={() => handleLogin('tiktok')} style={{ padding: '5px 10px', cursor: 'pointer', background: '#000', color: '#fff' }}>TikTok</button>
              <button onClick={() => handleLogin('twitter')} style={{ padding: '5px 10px', cursor: 'pointer', background: '#1DA1F2', color: '#fff' }}>X</button>
            </div>
          )}
        </div>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<AudioRecorder />} />
          <Route path="/d/:id" element={<ChallengeView />} />
          <Route path="/perfil" element={<ProfileView session={session} />} />
        </Routes>
      </main>
    </Router>
  )
}

export default App
