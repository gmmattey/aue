import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function signInWithGoogle() {
  return supabase.auth.signInWithOAuth({
    provider: 'google',
  });
}

import type { Provider } from '@supabase/supabase-js';

export async function signInWithTikTok() {
  return supabase.auth.signInWithOAuth({
    provider: 'tiktok' as Provider,
  });
}

export async function signInWithTwitter() {
  return supabase.auth.signInWithOAuth({
    provider: 'twitter' as Provider,
  });
}

export async function signInWithEmail(email: string) {
  return supabase.auth.signInWithOtp({ email });
}

export async function signOut() {
  return supabase.auth.signOut();
}

export async function createResult(resultData: any) {
  // Try to get current user session
  const { data: { session } } = await supabase.auth.getSession();
  
  const payload = {
    ...resultData,
    user_id: session?.user?.id || null
  };

  const { data, error } = await supabase
    .from('resultados')
    .insert([payload])
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

export async function createChallenge(challengerResultId: string) {
  // Generate a random 6 char ID
  const challengeId = Math.random().toString(36).substring(2, 8).toUpperCase();
  
  const { data, error } = await supabase
    .from('desafios')
    .insert([{ id: challengeId, challenger_result_id: challengerResultId }])
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

export async function getChallenge(challengeId: string) {
  const { data, error } = await supabase
    .from('desafios')
    .select('*, challenger_result:resultados!desafios_challenger_result_id_fkey(*), challenged_result:resultados!desafios_challenged_result_id_fkey(*)')
    .eq('id', challengeId)
    .single();
    
  if (error) throw error;
  return data;
}

export async function completeChallenge(challengeId: string, challengedResultId: string) {
  const { data, error } = await supabase
    .from('desafios')
    .update({ challenged_result_id: challengedResultId })
    .eq('id', challengeId)
    .select()
    .single();
    
  if (error) throw error;
  return data;
}
