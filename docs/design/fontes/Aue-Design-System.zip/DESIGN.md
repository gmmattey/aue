---
name: "Auê!"
category: Brands
surface: web
colors:
  preto-carv-o: "#0a0a08"
  superf-cie-elevada: "#171712"
  texto-claro: "#f5f3ea"
  texto-secund-rio: "#93917f"
  borda: "#2b2a22"
  verde-cido-el-trico: "#c6ff00"
---

# Auê!

> Category: Brands

> Surface: web

*Arrote. Receba a nota. Humilhe seus amigos.*

Jogo mobile casual de arrotos. A experiência principal é uma única Arena com estados de jogo — não um conjunto de telas, não um app social, não um webapp com navegação. Referências canônicas de UX/UI: arena.html + system/DESIGN.md.

## Color Palette

| Role | Name | Hex | Usage |
| --- | --- | --- | --- |
| background | Preto Carvão | `#0a0a08` | fundo do jogo, quase preto — tema canônico (não variante) |
| surface | Superfície Elevada | `#171712` | pílula de link, player, overlay, input — uso moderado |
| foreground | Texto Claro | `#f5f3ea` | texto principal e preenchimento de métrica |
| muted | Texto Secundário | `#93917f` | comentário do juiz, rótulos, metadados |
| border | Borda | `#2b2a22` | divisores sutis, raramente visíveis |
| accent | Verde Ácido Elétrico | `#c6ff00` | cor primária de destaque. Orçamento em ordem de prioridade: Bolha viva (gravando) → Auê Score → CTA primário. Máx. 2 aparições simultâneas. Evitar tom de verde hospitalar/vômito. Nunca no wordmark, na barra de métrica, na pílula de link ou no player. |

## Typography
- **Display:** Anton — weights 400 — fallbacks: Archivo Black, Impact, system-ui, sans-serif
- **Body:** Archivo — weights 400, 500, 600, 700 — fallbacks: Archivo Narrow, Inter, system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif (Grotesca esportiva, ombro reto. Inter permanece apenas como fallback tardio, nunca como primeira escolha.)
- **Mono:** ui-monospace — weights 400, 600 — fallbacks: JetBrains Mono, SF Mono, Menlo, monospace (Papel restrito: eyebrow, contador, código do X1, link, timestamp. Nunca corpo de texto.)

## Voice & Tone

- **Adjectives:** irreverente, competitivo, espontâneo, debochado, direto, engraçado
- **Tone:** Jogo mobile casual, não rede social/utilitário/app corporativo. Irreverência e humor pontual nos pontos de payoff (resultado, derrota, empate, erro, compartilhamento) sem virar piada em todo label. Microcopy curta, direta, sem texto técnico — ex.: 'MANDA.', 'JULGANDO ESSA PORRA...', 'A dignidade também.' Voz é sistema, não lista de palavras: rótulo de botão é contrato e nunca varia; a fala varia por pools de momento sem repetir a anterior; a reação ao resultado é escolhida por faixa de nota; estrutura fixa de duas linhas (fala principal em Display + comentário em muted, máx. 30ch). Ver DESIGN.md seção 14.

### Messaging pillars
- irreverência
- X1 direto
- espontaneidade
- suspense
- a nota como payoff
- humilhação compartilhável

### Vocabulary
- **Use:** ARROTAR, Auê Score, X1, REVANCHE, MANDAR, Arena, Placar, Grave/Estouro/Fôlego/Sujeira
- **Avoid:** DESAFIAR (substituído por X1), 'tela de X' para momentos de partida — são estados da Arena, rótulos de laudo nas métricas (Profundidade/Potência/Duração/Textura), jargão técnico (ex: 'baseline RMS'), linguagem de app corporativo/dashboard, onboarding longo/explicativo, piada em todo label, variar o rótulo de um botão entre sessões, vocabulário de feed, perfil, seguidores, comunidade, ranking global, conquistas, campeonatos, temporadas e assinatura

## Imagery

- **Style:** Contemporâneo, energético, propositalmente exagerado — party game premium + cultura digital + streetwear + esporte absurdo
- **Subjects:** Bolha Auê (componente proprietário animado, 13 modos, ver DESIGN.md seção 7), símbolo Bolha Viva com '!' integrado (marca estática, ver DESIGN.md seção 1), Auê Score em grande destaque, dentro da Bolha, bloco VS e placar tocável, pílulas de utilidade (link do X1 e player de replay)
- **Treatment:** Baixa densidade visual, tipografia grande, um elemento visual dominante por estado, motion que comunica estado (nunca decorativo), flat/vetorial — sem gradiente, sem glow, sem sombra decorativa
- **Avoid:** waveform tradicional como elemento principal, cards e gramática de app tradicional no gameplay, aparência de app corporativo/dashboard, dependência exclusiva de emojis para personalidade, gradiente ou glow em qualquer artefato de marca

## Layout

- **Radius:** 24px padrão de superfícies; 12px chips, 18px inputs/células, 32px shell do desktop, 999px pílulas. Escala completa em DESIGN.md seção 4.2
- **Border weight:** 1px, uso discreto
- **Spacing:** grid 8px; baixa densidade — grandes áreas vazias, poucas métricas simultâneas, informação progressiva

### Posture rules
- O jogo é uma Arena fullscreen e contínua com 19 estados, não um conjunto de telas nem rotas — escrever 'estado de RESULT', nunca 'tela de resultado'. Landing, termos e privacidade continuam sendo páginas, fora da Arena; ver DESIGN.md seção 12
- Uma ação principal por estado, hierarquia evidente
- Tema escuro é canônico, não variante — fundo quase preto, superfícies discretamente elevadas, textos claros
- Auê Score é inteiro de 0 a 100 (sem casa decimal), mora dentro da Bolha e tem protagonismo — 25–40% da atenção no estado de resultado
- RESULT_REVEAL prioriza exclusivamente a nota; ações secundárias e origem entram depois, em cascata, no RESULT
- A origem do arroto nunca bloqueia o caminho até a nota
- Métricas em linhas com barra de progresso, não em cards independentes; rótulos de rua (Grave/Estouro/Fôlego/Sujeira), preenchimento em --fg e não no accent
- Orçamento do accent: Bolha viva → Auê Score → CTA primário, máx. 2 aparições simultâneas. Nunca no wordmark, na barra de métrica, na pílula de link ou no player
- Botão primário grande, pílula, uppercase, alto contraste; evitar três CTAs igualmente chamativos
- Não existe navegação, bottom navigation nem tab bar — só o HUD (wordmark + marca de X1 + menu), que some em RECORDING, VALIDATING, JUDGING, RESULT_REVEAL e REMATCH. Menus ficam fora do fluxo principal, como overlay
- Gameplay não usa cards nem gramática de app tradicional
- Erros e recuperação acontecem dentro da Arena, como estados — nunca como página ou rota de erro
- X1, placar e revanche fazem parte do mesmo sistema visual da Arena
- Mobile-first, viewport 360–430px, uma mão; grade fixa de 4 faixas (HUD / palco / reação / ação)
- Desktop é o mesmo jogo em shell de 440px com raio 32px — não uma versão esticada
- Motion transmite estado e feedback, nunca é decoração; prefers-reduced-motion mantém a informação completa
- Bolha Auê é o elemento vivo central, componente proprietário com 13 modos — nunca decoração; ver DESIGN.md seção 7
- Anúncios não são estado de jogo: se existirem, são integração futura opcional entre rodadas; ver DESIGN.md seção 20
